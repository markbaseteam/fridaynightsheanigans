[[Chp1 Prisoners of the Drow]]
[[Escape!]]
[[The Adventure Begins]]
[[In the Slave Pen]]
[[The Drow]]
[[Velkynvelve]]
[[Means of Escape]]
[[Leaving Velkynvelve]]
[[XP Awards]]

Chp2 Into Darkness
Where to Go?
Underdark Travel
Equipment
Madness
Death
Fungi of the Underdark
Narrating the Journey
Drow Pursuit
Random Encounters
Summarizing Travel
Set Encounters
The Silken Path
Hook Horror Hunt
The Oozing Temple
Lost Tomb of Khaem

Chp3 The Darklake
Traversing the Darklake
Random Encounters
Sloobludop
XP Awards

Chp4 Gracklstugh
Going to Gracklstugh
Gracklstugh
Darklake District
Laduguer's Furrow
West Cleft & East Cleft Districts
Halls of Sacred Spells
Cairngorm Cavern
Themberchaud's Lair
Whorlstone Tunnels
Leaving Gracklstugh
Hold of the Deepking

Chp5 Neverlight Grove
Going to Neverlight Grove
Arriving at the Grove
Neverlight Grove
Yggmorgus
Leaving Neverlight Grove

Chp6 Blingdenstone
Going to Blingdenstone
Blingdenstone Outskirts
Outer Blingdenstone
Inner Blingdenstone
Rockblight
Goldwhisker Warrens
The Pudding Court
Battle for Blingdenstone
Leaving Blingdenstone

Chp7 Escape from the Underdark
The Way Out
Bidding Farewell
Confronting the Drow
Further Adventures

Ch. 8: Audience in Gauntlgrym
Summoned by Bruenor
Gauntlgrym
Events in Gauntlgrym
Forging an Alliance
The Way Ahead

Ch. 9: Mantol-Derith
Fraz-Urb'luu's Gem
Reaching Mantol-Derith
Mantol-Derith
Leaving Mantol-Derith

Ch. 10: Descent into the Depths
Fellow Travelers
In Command
Random Events
Underdark Outposts
Retracing Steps

Ch. 11: Gravenhollow
Going to Gravenhollow
The Stone Library
The Enemy of Our Enemy
Stonespeaker Crystals
Returning to Vizeran
Leaving Gravenhollow

Ch. 12: The Tower of Vengeance
Reaching the Tower
Araj: Vizeran's Tower

Ch. 13: The Wormwrithings
The Worm Tunnels
Troglodyte Lair
Voice in the Dark
Worm Nursery
The Dark Hunters
The Vast Oblivium

Ch. 14: The Labyrinth
Labyrinth Encounters
Adamantine Tower
Spiral of the Horned King
Filthriddens
March to Nowhere
Yeenoghu's Hunt
Gallery of Angels
The Maze Engine

Ch. 15: The City of Spiders
Goals
Going to Menzoberranzan
Menzoberranzan
City Locations
Unexpected Allies
Private Meetings
A Change of Heart
Sorcere
Developments

Ch. 16: The Fetid Wedding
Wedding Invitation
Myconid March
Araumycos
Enter the Groom
Into the Gray Dream
Let Them Speak Now
Fighting the Faceless Lord
Victory or Defeat
Developments

Ch. 17: Against the Demon Lords
Readying the Plan
Enacting the Plan
Rage of Demons
Against Demogorgon
Loose Threads



Appendix A: Modifying Backgrounds
Substitute Features
Substitute Bonds
Appendix B: Magic Items
Appendix C: Creatures
Derro
Ixitxachitl
Creature Variations
Miscellaneous Creatures
Nonplayer Characters
Appendix D: Demon Lords
Baphomet
Demogorgon
Fraz-Urb'luu
Graz'zt
Juiblex
Orcus
Yeenoghu
Zuggtmoy
Afterword
Credits